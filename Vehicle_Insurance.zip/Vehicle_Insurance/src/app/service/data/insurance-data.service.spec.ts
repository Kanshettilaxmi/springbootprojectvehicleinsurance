import { TestBed } from '@angular/core/testing';

import { InsuranceDataService } from './insurance-data.service';

describe('InsuranceDataService', () => {
  let service: InsuranceDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(InsuranceDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
